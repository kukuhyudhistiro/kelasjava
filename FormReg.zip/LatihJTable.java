/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author x220
 */
import javax.swing.JFrame; 
import javax.swing.JScrollPane; 
import javax.swing.JTable; 

public class LatihJTable {
     // frame 
    JFrame f; 
    // Table 
    JTable j; 
  
    LatihJTable() 
    { 
        // Inisialisasi Frame
        f = new JFrame(); 
  
        // Judul Frame 
        f.setTitle("Contoh JTable"); 
  
        // data
        String[][] data = { 
            { "Kukuh Yudhistiro", "Pria", "Surabaya" }, 
            { "Novita", "Wanita", "Denpasar" },
            {"ewrewr", "435435" ,"Male"},
            {"retertre", "5345435", "Male"}
        }; 
  
        // Nama Kolom 
        String[] columnNames = { "Nama", "Jenis Kelamin", "Kota" }; 
  
        // set up tabel/grid 
        j = new JTable(data, columnNames); 
        j.setBounds(30, 40, 200, 300); 
  
   
        JScrollPane sp = new JScrollPane(j); 
        f.add(sp); 
        // Ukuran Frame 
        f.setSize(500, 200); 
        // Frame Visible = true 
        f.setVisible(true); 
    } 
  
    
    public static void main(String[] args) 
    { 
        new LatihJTable(); 
    } 
    
}
