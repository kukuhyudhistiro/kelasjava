/*
 * Project pertama menggunakan JAVA - Netbeans.
 * Project ini sebagai latihan awal Java
 * By: Kukuh - 11/09/2019
 */

/**
 *
 * @author x220
 */
public class main {
    public static void main(String args[]){
        System.out.println("Ini program Java-ku yang pertama!");
        
        int x = 10;
        int y = 5;
        int z = x-y;
        System.out.println("Nilai x = "+ x);
        System.out.println("Nilai x = "+ y);
        System.out.println("x + y = " + z);
        
        String nama = "Budi";
        System.out.println("Nama saya : " + nama );   
    }
    
    
}
