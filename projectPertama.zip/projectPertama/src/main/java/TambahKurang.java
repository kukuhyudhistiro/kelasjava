/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kukuh
 */
public class TambahKurang {
    public static void main(String[] arg){
        int x,y;
        //contoh untuk metode ++
        x = 6;
        y = ++x;
        System.out.println("Hasil y = ++x");
        System.out.println("y = " + y + " , " +  "x = " + x);
        
    }
    
}
